"""
Vacancy Predictor - ML Tool for vacancy prediction
"""

__version__ = "3.0.0"