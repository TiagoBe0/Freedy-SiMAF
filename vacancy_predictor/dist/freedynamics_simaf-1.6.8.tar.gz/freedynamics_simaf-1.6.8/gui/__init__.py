from .app import VacancyPredictorGUIEnhanced

__all__ = ['VacancyPredictorGUI']